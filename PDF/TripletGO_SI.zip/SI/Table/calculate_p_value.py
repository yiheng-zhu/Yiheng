from scipy import stats
import sys
import Extract_Measures as ep
import Extract_measures_mlc as em


def calculate(workdir):

    single_method_list = ["mr", "pcc", "wip", "src", "ed"]
    data_type = "test"
    metric_list = ["fmax", "AUPR"]
    type_list = ["MF", "BP", "CC"]

    for metric in metric_list:
        for type in type_list:

            my_result_file = workdir + "/" + type + "/record"
            other_result_file = workdir + "/single_result"
            mlc_file = workdir + "/mlc_result"

            my_method_dict = ep.extract_from_my_method(my_result_file)
            other_method_dict = ep.extract_from_other_pipelines(other_result_file)
            mlc_method_dict = em.extract(mlc_file)

            values1 = my_method_dict[type][data_type][metric]

            for method in single_method_list:
                if (method != "wip"):

                    values2 = other_method_dict[type][method][data_type][metric]
                    print("%.2e" % stats.ttest_1samp(values1, values2)[1], end=" ")
                else:

                    values2 = mlc_method_dict[type][data_type][metric]
                    print("%.2e" % stats.ttest_ind(values1, values2)[1] , end=" ")
                if(method=="ed"):
                    print("")




if __name__=="__main__":

    spiece_list =["Nematoda"]

    for spiece in spiece_list:
        calculate(sys.argv[1]+"/"+spiece+"/")



